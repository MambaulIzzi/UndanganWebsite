const nama_pasangan = 'Obi & Ica';
const tanggal_pernikahan = '14 jan 2024 08:00:00';

export {nama_pasangan, tanggal_pernikahan}