import Beranda from "./Pages/Beranda";

function App() {
  return (
    <>
      <Beranda />
    </>
  );
}

export default App;
